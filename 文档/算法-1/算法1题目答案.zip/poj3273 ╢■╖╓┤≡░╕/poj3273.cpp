#include<iostream>
#include<cstring>
#include<cmath>
#define maxm 10000000
#define inf 1<<30
using namespace std;

int an[maxm];
int n,m;
bool neng(int k)
{
    int i,sum = 0,num = 1;
    bool bl;
    for(i = 0,bl =0;i < n;i++)
    {
        if(sum+an[i]<=k)
        {
            sum+=an[i];
            bl = 1;
        }
        else
        {
            if(!bl) return 0;
            else
            {
                sum = 0;
                i--;
                num++;
                bl = 0;
            }
        }
    }
    if(num>m) return 0;
    return 1;
}

int find(int low,int high)
{
    int mid = (long long)(low+high)/2;
    if(low == high) return high;
    if(neng(mid)) high = mid;
    else low = mid + 1;
    return find(low,high);
}
int main()
{
    int i,j,k,mx;
    while(cin>>n>>m)
    {
        mx = -inf;
        for(i = 0;i<n;i++)
        {
            cin>>an[i];
            mx = max(mx,an[i]);
        }
        cout<<find(mx,inf);
    }
}
