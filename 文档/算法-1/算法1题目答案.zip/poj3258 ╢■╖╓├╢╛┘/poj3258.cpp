#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>

using namespace std;

int an[60000];
int l,m,n;
bool neng(int k)
{
    int i,j,num = 0;
    for(i = 1,j = 0;i<= n+1;i++)
    {
        if(an[i]-j>=k) j = an[i];
        else num++;
    }
    if(num>m) return 0;
    return 1;
}
int findk(int low,int high)
{
    int mid = ((long  long)(low+high+1))/2;
    if(low == high) return low;
    if(neng(mid)) low = mid;
    else high = mid - 1;
    return findk(low,high);
}

int main()
{
    int i;
    scanf("%d%d%d",&l,&n,&m);
    an[0] = 0,an[n+1] = l;
    for(i = 1;i<=n;i++)
        scanf("%d",&an[i]);
    sort(an,an+n+2);
    printf("%d\n",findk(0,l));
    return 0;
}
