#include <iostream>
#include<cmath>
#include<cstdio>
#define eps 1e-5
using namespace std;
int p,q,r;
double a1,a2,b1,b2,c1,c2,d1,d2;
double findkcd(double x1,double y1,double x2,double y2,double x,double y);
double ql(double x1,double y1,double x2,double y2)
{
    return sqrt((x2-x1)*(x2-x1) + (y2 - y1)*(y2-y1));
}
double qt(double x1,double y1,double x2,double y2)
{
    double t1,t2,t3;
    t1 = ql(a1,a2,x1,y1)/p;
    t2 = ql(d1,d2,x2,y2)/q;
    t3 = ql(x1,y1,x2,y2)/r;
    return t1+t2+t3;
}

double findkab(double x1,double y1,double x2,double y2)
{
    double xx = (x2 - x1)/3,yy = (y2-y1)/3;
    double xx1 = x1+xx,yy1 = y1+yy,   xx2 = x2-xx,yy2 = y2-yy;
    double t1,t2;
    t1 = findkcd(c1,c2,d1,d2,xx1,yy1);
    t2 = findkcd(c1,c2,d1,d2,xx2,yy2);
    if(fabs(t2-t1)<eps) return t1;
    if(t1>t2)
        return findkab(xx1,yy1,x2,y2);
    else
        return findkab(x1,y1,xx2,yy2);

}
double findkcd(double x1,double y1,double x2,double y2,double x,double y)
{
    double xx = (x2 - x1)/3,yy = (y2-y1)/3;
    double xx1 = x1+xx,yy1 = y1+yy,   xx2 = x2-xx,yy2 = y2-yy;
    double t1,t2;
    t1 = qt(x,y,xx1,yy1);
    t2 = qt(x,y,xx2,yy2);
    if(fabs(t2-t1)<eps) return t1;
    if(t1>t2)
        return findkcd(xx1,yy1,x2,y2,x,y);
    else
        return findkcd(x1,y1,xx2,yy2,x,y);
}

int main()
{
    int t;
    int i,j,k;
    double time,l1,l2,l3;
    cin>>t;
    for(i = 0;i<t;i++)
    {
        cin>>a1>>a2>>b1>>b2;
        cin>>c1>>c2>>d1>>d2;
        cin>>p>>q>>r;
        printf("%.2lf\n",   findkab(a1,a2,b1,b2));
    }
    return 0;
}
