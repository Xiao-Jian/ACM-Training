#include<iostream>
#include<set>
#include<iterator>
using namespace std;

int an[110000];
int main()
{
    int t,n,i,j,a,b,sum;
    multiset<int>::iterator itr;
    cin>>t;
    for(i = 0;i<t;i++)
    {
        cin>>n;
        sum = 0;
        for(j = 0;j<n;j++)
        {
            cin>>an[j];
        }
        multiset<int> s(an,an+n);
        for(j = 0;j<n-1;j++)
        {
            itr = s.begin();
            a = *itr;
            s.erase(itr);
            itr = s.begin();
            b = *itr;
            s.erase(itr);
            a+=b;
            sum+=a;
            s.insert(a);
        }
        cout<<sum<<endl;
    }
    return 0;
}
