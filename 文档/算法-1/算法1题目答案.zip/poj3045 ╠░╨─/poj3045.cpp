#include<iostream>
#include<algorithm>
#define inf 1<<30
using namespace std;

struct niu
{
    int w;
    int s;
    int sum;
}nn[60000];

bool cmp(niu n1,niu n2)
{
    return n1.sum<n2.sum;
}
int main()
{
    int n,i,j;
    cin>>n;
    for(i = 0;i<n;i++)
    {
        cin>>nn[i].w;
        cin>>nn[i].s;
        nn[i].sum = nn[i].w+ nn[i].s;
    }
    sort(nn,nn+n,cmp);
    long long w = 0,fx = -inf;
    for(i = 0;i<n;i++)
    {
        fx = max(fx,w - nn[i].s);
        w+=nn[i].w;
    }
    cout<<fx<<endl;
    return 0;
}
