#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<algorithm>

using namespace std;

int an[11000],bn[11000],cn[11000],dn[11000];
int en[16100000];

int main()
{
    int n,i,j,k,ans = 0;
    cin>>n;
    for(i = 0;i<n;i++)
        scanf("%d%d%d%d",&an[i],&bn[i],&cn[i],&dn[i]);
    int num = 0;
    for(i = 0;i<n;i++)
        for(j = 0;j<n;j++)
            en[num++] = cn[i]+dn[j];
    sort(en,en+num);
//    for(i = 0;i<num;i++)
//        cout<<en[i]<<" ";
//    cout<<endl;
    for(i = 0;i<n;i++)
        for(j = 0;j<n;j++)
        {
            int t = an[i]+bn[j];
            t = -t;
            int low = 0,high = num-1,mid;
            while(low<=high)
            {
                mid = (low+high)/2;
                if(en[mid] == t) break;
                if(en[mid]>t) high = mid-1;
                else low = mid+1;
            }
            if(en[mid] == t)
            {
                ans++;
                int s;
                for(s = 1;s+mid<num;s++)
                {
                    if(en[s+mid]!=en[mid]) break;
                    ans++;
                }
                for(s = -1;s+mid>=0;s--)
                {
                    if(en[s+mid]!=en[mid]) break;
                    ans++;
                }
            }
        }
    printf("%d\n",ans);
    return 0;
}
