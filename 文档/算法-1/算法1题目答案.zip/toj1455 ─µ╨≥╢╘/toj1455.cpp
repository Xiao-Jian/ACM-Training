#include<iostream>

using namespace std;

int an[510000];

long long merge(int*list1,int size1,int *list2,int size2)
{
    int i,j,k;
    long long num;
    i = j = k = num = 0;
    int* list = new int [size1+size2] ;
    while(i<size1&&j<size2)
    {
        if(list1[i]<=list2[j])
        {
            list[k++] = list1[i++];
            num+=j;
        }
        else list[k++] = list2[j++];
    }
    while (i < size1)
    {
        list[k++] = list1[i++];
        num+=j;
    }
     while (j < size2)
        list[k++] = list2[j++];
    for (int ii = 0; ii < (size1 + size2); ++ii)
        list1[ii] = list[ii];
    delete [] list;
    return num;
}
long long mergesort(int*list,int size)
{
    if(size <= 1) return 0;
     int* list1 = list;
     int size1 = size/2;
     int* list2 = list+size1;
     int size2 = size - size1;
     return mergesort(list1,size1)
        +mergesort(list2,size2)
        +merge(list1,size1,list2,size2);
}
int main()
{
    int n,i,j;
    while(1)
    {
        cin>>n;
        if(n == 0) return 0;
        for(i = 0;i<n;i++)
            cin>>an[i];
        cout<<mergesort(an,n)<<endl;
    }
}
