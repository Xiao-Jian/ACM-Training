#include<iostream>
#define m 2006
using namespace std;
int n;
long long pow(int a)
{
    if(a == 0) return 1;
    if(a%2==0) return (pow(a/2)*pow(a/2))%m;
    else return(pow(a/2)*pow(a/2)*n)%m;
}

int main()
{
    while(cin>>n)
    {
        if(n == 0) return 0;
        cout<<pow(n)<<endl;
    }
}
