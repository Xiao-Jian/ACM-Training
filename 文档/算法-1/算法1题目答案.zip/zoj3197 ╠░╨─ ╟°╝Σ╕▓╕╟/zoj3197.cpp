#include<iostream>
#include<algorithm>

 using namespace std;

struct qj
{
    int l,r;
}q[1000000];

bool cmp(qj q1,qj q2)
{
    return q1.l<q2.l;
}
int main()
{
    int t,n,i,j,l,r,rm,dyl,num;
    cin>>t;
    while(t--)
    {
        cin>>n;
        for(i = 1;i<=n;i++)
            cin>>q[i].l>>q[i].r;
        q[n+1].l  = 1<<29;
        sort(q+1,q+1+n,cmp);
        int ans=0;
        int l=0,r=0,cur=0;
        for(int i=1;i<=n+1;i++)
        {
            if(cur>=n) break;
            if(q[i].l<=cur+1)
              r=max(r,q[i].r);
            else
            {
                ans++;
                cur=r;
                r=q[i].r;
            }
        }
        cout<<ans<<endl;
    }
    return 0;
}
