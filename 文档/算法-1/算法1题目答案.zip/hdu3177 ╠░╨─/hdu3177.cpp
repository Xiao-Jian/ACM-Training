#include<iostream>
#include<algorithm>
using namespace std;

struct ab
{
    int a;
    int b;
}an[10000];

bool cmp(ab a1,ab a2)
{
    return (a1.b-a1.a)>(a2.b-a2.a);
}
int main()
{
    int t,n,v,i,mb,dya,sum,a,b,flag;
    cin>>t;
    while(t--)
    {
        cin>>v>>n;
        sum = 0;
        mb = 1<<29;
        for(i = 0;i<n;i++)
            cin>>an[i].a>>an[i].b;
        sort(an,an+n,cmp);
        sum = 0,flag = 1;
        for(i = 0;i<n;i++)
        {
            if(sum +an[i].b>v) flag = 0;
            sum += an[i].a;
        }
        if(flag) cout<<"Yes\n";
        else cout<<"No\n";
    }
}
