#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
#define pi acos(-1)
#define eps 1e-5
using namespace std;

int n,m;
int an[11000];

bool neng(double k)
{
    int num = 0;
    for(int i = 1;i<=n;i++)
    {
        double s = an[i]*an[i]*pi;
        num+=int (s/k);
        if(num>m)return 1;
    }
    return 0;
}

double findk(double low,double high)
{
    double mid = (low+high)/2;
    if(high-low<eps) return mid;
    if(neng(mid)) return findk(mid,high);
    else return findk(low,mid);
}

int main()
{
    int z;
    cin>>z;
    while(z--)
    {
        int i,j;
        scanf("%d%d",&n,&m);
        for(i = 1;i<=n;i++)
            scanf("%d",&an[i]);
        double k = findk(0,1e20);
        printf("%.4lf\n",k);
    }
    return 0;
}
