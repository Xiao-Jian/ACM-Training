#include <iostream>
#include<cstdio>
#include<cmath>
#include<cstdlib>
#define pi acos(-1.0)
#define eps 1e-7

using namespace std;

double s;

double qh(double r)
{
    return sqrt(s*s/(pi*pi*r*r) - 2*s/pi);
}
double qv(double r)
{
    double ds = pi*r*r;
    return qh(r)*ds/3;
}
void findk(double a,double b)
{
    double c = (b-a)/3;
    double aa = a+c,  bb = b-c;
    double v1,v2;
    v1 = qv(aa);
    v2 = qv(bb);
    if(fabs(aa-bb)<eps)
    {
        printf("%.2lf\n%.2lf\n%.2lf\n",v1,qh(aa),aa);
        return ;
    }
    if(v1>v2) findk(a,bb);
    else findk(aa,b);
}
int main()
{
    while(cin>>s)
    {
        double rm = sqrt(s/(2*pi));
        findk(0,rm);
    }
    return 0;
}
