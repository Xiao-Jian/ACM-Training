#include<iostream>
#include<set>
#include<iterator>
using namespace std;

int an[30000];

int main()
{
    int n,i,j;
    long long sum = 0,a,b;
    cin>>n;
    for(i =0;i<n;i++)
        cin>>an[i];
    multiset<long long>::iterator itr;
    multiset<long long> s(an,an+n);
    for(j = 0;j<n-1;j++)
    {
        itr = s.begin();
        a = *itr;
        s.erase(itr);
        itr = s.begin();
        b = *itr;
        s.erase(itr);
        a+=b;
        sum+=a;
        s.insert(a);
    }
    cout<<sum<<endl;
    return 0;
}
