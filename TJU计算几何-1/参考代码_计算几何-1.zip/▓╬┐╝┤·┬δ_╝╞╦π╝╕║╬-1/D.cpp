#include <cmath>
#include <cstdio>
#include <algorithm> 
using namespace std;

#define N 105
#define eps 1e-6//����̫С�ᵼ�³���������̫������Ӽ��������Լ�Ȩ�� 
struct point {
    double x, y;
    point(){}
    point(double x, double y):x(x), y(y){}
    point operator + (const point o) const{
        return point(x+o.x, y+o.y);
    }
    point operator - (const point o) const{
        return point(x-o.x, y-o.y);
    }

    double operator * (const point o) const{
        return x*o.y - o.x*y;
    }

    double operator ^ (const point o) const{//���
        return x*o.x + y*o.y;
    }

    point operator * (const double a) const{
        return point(a*x, a*y);
    }

    double len2()
    {
        return x*x + y*y;
    }
}a, b, s, t;

point Intersection(point a, point b, point c, point d)
{
    double t = ((d - a)*(c - a))/((b - a)*(d - c));
	return a + (b-a)*fabs(t);
}

int main()
{
	point a, b, c, d;
	int T;
	scanf("%d", &T);
	while(T--)
	{
		scanf("%lf %lf %lf %lf", &a.x, &a.y, &b.x, &b.y);
		scanf("%lf %lf %lf %lf", &c.x, &c.y, &d.x, &d.y);
		
		if(fabs(a.y - b.y) < eps || fabs(c.y - d.y) < eps)//��ˮƽ�� 
		{
			puts("0.00");
			continue;
		}
		
		if(a.y < b.y) swap(a, b);
		if(c.y < d.y) swap(c, d);
		
		if(fabs((b.y-a.y)*(d.x-c.x) - (d.y-c.y)*(b.x-a.x)) < eps) //������ƽ�� 
		{
			puts("0.00");
			continue;
		}
		
		if(((b-a)*(c-a))*((b-a)*(d-a)) > 0 || ((d-c)*(a-c))*((d-c)*(b-c)) > 0)//�����߶θ���û�н��� 
		{
			puts("0.00");
			continue;
		}
		point p = Intersection(a, b, c, d); 
		point up = point(0,10); 
		if(((a-p)*(up)) * ((c-p)*(up)) > 0)//���ռ���ˮ�Ĳ�������ֱ�ߵ�ͬһ��
		{
			if((a-p)*(c-p) > 0 && c.x- a.x>= -eps)
			{
				puts("0.00");
				continue;
			}
			if((a-p)*(c-p) < 0 && a.x- c.x>= -eps)
			{
				puts("0.00");
				continue;
			}
		}
		point t1, t2;
		t1.y = t2.y = min(a.y, c.y);
		t1.x = a.x + (b.x - a.x)*(t1.y - a.y)/(b.y-a.y);
		t2.x = c.x + (d.x - c.x)*(t2.y - c.y)/(d.y-c.y);
		double ans = fabs((t1.x - t2.x) * (t1.y-p.y)/2.0);
		printf("%.2f\n", ans+eps); //���ƾ��ȣ� 
	}
	return 0;
}
