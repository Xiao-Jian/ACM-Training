#include <cstdio>
#include <cmath>
using namespace std;
#define eps 1e-8
#define N 105
struct point{
	double x, y;
	point(){}
	point(double _x, double _y) {
		x = _x, y = _y;
	}
	
	point operator - (point a){
		return point(x-a.x, y-a.y);
	}
	
	double operator * (point a){
		return x*a.y - y*a.x;
	}
};
point p[N];

int main()
{
	int n;
	while(~scanf("%d", &n), n)
	{
		for(int i = 0; i < n; i++)
			scanf("%lf %lf", &p[i].x, &p[i].y);
		double ans = 0;
		for(int i = 1; i < n-1; i++)
			ans += ((p[i]-p[0])*(p[i+1]-p[0]));

		printf("%.1f\n", 0.5*fabs(ans));
	}
}
