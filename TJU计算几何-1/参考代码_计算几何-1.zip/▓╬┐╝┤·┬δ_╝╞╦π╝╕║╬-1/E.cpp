#include <cstdio>
#include <cmath>
#include <algorithm>
using namespace std;

#define eps 1e-8
#define pi acos(-1.0)
#define N 750

int n;

struct point
{
    double x, y;
    point(){}
    point(double _x, double _y ):x(_x), y(_y){}
};

point P[N];
double ang[2*N];
int main()
{
	//printf("%d", 700*699*698/6);
   int T, n;
   scanf("%d", &T);
   while(T--)
   {
        scanf("%d", &n);
        for(int i = 0; i < n; i++)
            scanf("%lf %lf", &P[i].x, &P[i].y);

        long long ans = (long long)n*(n-1)*(n-2)*(n-3)/24;//C(n,4)
        for(int i = 0; i < n; i++)
        {
            long long cnt = (long long)(n-1)*(n-2)*(n-3)/6;//cnt��¼����i�������θ���

            int c = 0;
            for(int j = 0; j < n; j++)
            {
                if(i == j) continue;
                ang[c++] = atan2(P[j].y-P[i].y, P[j].x - P[i].x);
            }

            sort(ang, ang+c);
            for(int j = c; j < 2*c; j++)
            {
                ang[j] = ang[j-c] + 2*pi;
           //     printf("a--   %lf\n", ang[j-c] * 180.0 /pi);
            }
           // puts("");

            int k = 1;

            //puts("haha");while(t < 1000000000) t++;
            for(int j = 0; j < c; j++)//������i��������
            {
                while(ang[k] - ang[j] < pi) k++;
                int d = k-j-1;
             //   printf("d = %d\n", d);
                if(d > 1) cnt -= d*(d-1)/2;
            }

            ans -= cnt;
        }
        printf("%I64d\n",ans);
   }
   return 0;
}
