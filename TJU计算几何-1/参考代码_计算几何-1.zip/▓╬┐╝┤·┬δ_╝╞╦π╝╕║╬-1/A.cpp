#include <cstdio>
#include <cmath>
using namespace std;
#define eps 1e-8
#define N 105
struct point{
	double x, y;
	point(){}
	point(double _x, double _y) {
		x = _x, y = _y;
	}
	
	point operator - (point a){
		return point(x-a.x, y-a.y);
	}
	
	double operator * (point a){
		return x*a.y - y*a.x;
	}
};

struct line{
	point s, t;
}L[N];

bool ck(line a, line b)
{
	point A = a.s, B = a.t, C = b.s, D = b.t;
	if(((C-A)*(B-A)) *((D-A)*(B-A)) > eps) return false;
	if(((A-C)*(D-C)) *((B-C)*(D-C)) > eps) return false;
	return true;
}

int main()
{
	int n;
	while(~scanf("%d", &n), n)
	{
		for(int i = 0; i < n; i++)
			scanf("%lf %lf %lf %lf", &L[i].s.x, &L[i].s.y, &L[i].t.x, &L[i].t.y);
		int cnt = 0;
		for(int i = 0; i < n; i++)
			for(int j = i+1; j < n; j++)
				cnt += ck(L[i], L[j]);
		printf("%d\n", cnt);
	}
}
