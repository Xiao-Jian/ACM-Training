#include <cstdio>
#include <cmath>
#include <algorithm>
using namespace std;
#define eps 1e-6
#define N 25
#define INF 20000
#define pi acos(-1.0)
struct point{
	double x, y;
	point(){}
	point(double _x, double _y) {
		x = _x, y = _y;
	}
	
	point operator - (point a){
		return point(x-a.x, y-a.y);
	}
	
	double operator * (point a){
		return x*a.y - y*a.x;
	}
	
	double len(){
		return sqrt(x*x+y*y);
	}
};
struct circle{
	point c;
	double r;
};
circle cir[N];
int n;

double dist(point a, point b)
{
	return (b-a).len();
}

double area_cir_to_cir(circle a,circle b) 
{
	double d=dist(a.c,b.c),r1=a.r,r2=b.r,r; 
	if (r1+r2<=d) { return 0.0; } 
	else if (fabs(r1-r2)>=d) { 
		r=min(r1,r2); 
		return pi*r*r; 
	} 
	else { 
		double a1=(r1*r1+d*d-r2*r2)/(2*r1*d); 
		double a2=(r2*r2+d*d-r1*r1)/(2*r2*d); 
		a1=2*acos(a1); a2=2*acos(a2); 
		return (r1*r1*(a1-sin(a1))+r2*r2*(a2-sin(a2)))*0.5; 
	} 
}

bool check(circle a, circle b)
{
	double s1 = area_cir_to_cir(a, b);
	double s2 = pi*b.r*b.r;
	return s1*2 > s2-eps;
}

bool check(point o, double r)
{
	circle t;
	t.c = o, t.r = r;
	for(int i = 0; i < n; i++)
		if(!check(t, cir[i]))return false;
	return true;
}

double solve(int id)
{
	point o = cir[id].c;
	double l = 0, r = INF;
	while(fabs(l-r) > eps)
	{
		double m = 0.5*(l+r);
		if(check(o, m)) r = m;
		else l = m;
	}
	return l;
}

int main()
{
	int T;
	scanf("%d", &T);
	while(T--)
	{
		scanf("%d", &n);
		for(int i = 0; i < n; i++)
			scanf("%lf %lf %lf", &cir[i].c.x, &cir[i].c.y, &cir[i].r);
		double ans = INF;
		for(int i = 0; i < n; i++)
			ans = min(ans, solve(i));
		printf("%.4f\n", ans);
	}
}
